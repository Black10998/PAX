/**
 * PAX Support Pro - Unified Chat Engine
 * Merges Assistant + Live Agent into single interface with mode switching
 * 
 * @package PAX_Support_Pro
 * @version 5.4.8
 */

(function() {
    'use strict';

    class PAXUnifiedChat {
        constructor() {
            this.currentMode = 'assistant'; // 'assistant' | 'liveagent'
            this.sessions = {
                assistant: {
                    messages: [],
                    context: {},
                    history: []
                },
                liveagent: {
                    sessionId: null,
                    messages: [],
                    status: 'idle', // 'idle' | 'pending' | 'active' | 'closed'
                    agentInfo: null,
                    unreadCount: 0
                }
            };
            this.replyToMessage = null;
            this.pollInterval = null;
            this.isPolling = false;
            this.lastMessageId = 0;
            
            // DOM elements
            this.chatWindow = null;
            this.messageContainer = null;
            this.inputField = null;
            this.sendButton = null;
            this.modeSwitcher = null;
            
            this.init();
        }

        init() {
            // Wait for DOM ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.setup());
            } else {
                this.setup();
            }
        }

        setup() {
            // Get DOM elements
            this.chatWindow = document.getElementById('pax-chat');
            this.messageContainer = document.getElementById('pax-messages');
            this.inputField = document.getElementById('pax-input');
            this.sendButton = document.getElementById('pax-send');
            
            if (!this.chatWindow || !this.messageContainer) {
                console.warn('PAX Unified Chat: Required DOM elements not found');
                return;
            }

            // Load saved state
            this.loadState();

            // Setup mode switcher
            this.setupModeSwitcher();

            // Setup event listeners
            this.setupEventListeners();

            // Setup Quick Actions
            this.setupQuickActions();

            // Setup Chat Menu (three-lines button)
            this.setupChatMenu();

            // Setup toggle button
            this.setupToggleButton();

            // Show welcome message if no messages
            if (this.sessions[this.currentMode].messages.length === 0) {
                this.showWelcomeMessage();
            }

            // Restore current mode
            this.switchMode(this.currentMode, false);

            console.log('PAX Unified Chat initialized in', this.currentMode, 'mode');
        }

        setupToggleButton() {
            // v5.4.3: Unified launcher integrated into core system
            const launcher = document.getElementById('pax-unified-launcher');
            if (!launcher) {
                console.warn('PAX Unified Chat: Launcher not found');
                return;
            }

            // Apply settings-based positioning
            this.applyLauncherSettings(launcher);

            // Main launcher click handler
            launcher.addEventListener('click', () => {
                this.toggleChat();
            });

            // Close button
            const closeBtn = document.getElementById('pax-close');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    this.closeChat();
                });
            }

            // Overlay click to close
            const overlay = document.getElementById('pax-chat-overlay');
            if (overlay) {
                overlay.addEventListener('click', () => {
                    this.closeChat();
                });
            }

            console.log('PAX Unified Launcher initialized');
        }

        applyLauncherSettings(launcher) {
            if (!launcher) return;

            // Get position from data attribute
            const position = launcher.dataset.position || 'bottom-right';
            
            // Apply position class
            launcher.classList.add(`position-${position}`);

            // Apply color scheme from settings if available
            if (window.paxSupportPro && window.paxSupportPro.options) {
                const opts = window.paxSupportPro.options;
                
                // Apply custom colors via CSS variables
                if (opts.color_accent) {
                    launcher.style.setProperty('--launcher-bg', opts.color_accent);
                }
            }
        }

        toggleChat() {
            const isOpen = this.chatWindow.classList.contains('open');
            
            if (isOpen) {
                this.closeChat();
            } else {
                this.openChat();
            }
        }

        openChat() {
            this.chatWindow.classList.add('open');
            
            const overlay = document.getElementById('pax-chat-overlay');
            if (overlay) {
                overlay.classList.add('open');
            }

            // v5.4.4: Prevent body scroll on mobile
            if (window.innerWidth <= 768) {
                document.body.classList.add('pax-chat-open');
            }

            // Focus input
            if (this.inputField) {
                setTimeout(() => {
                    this.inputField.focus();
                }, 300);
            }

            // Start polling if in liveagent mode
            if (this.currentMode === 'liveagent') {
                this.startPolling();
            }
        }

        closeChat() {
            this.chatWindow.classList.remove('open');
            
            const overlay = document.getElementById('pax-chat-overlay');
            if (overlay) {
                overlay.classList.remove('open');
            }

            // v5.4.4: Restore body scroll on mobile
            document.body.classList.remove('pax-chat-open');

            // Close any open menus
            this.closeChatMenu();
            this.closeQuickActionsMenu();

            // Stop polling when chat is closed
            if (this.currentMode === 'liveagent') {
                this.stopPolling();
            }
        }

        setupModeSwitcher() {
            const header = this.chatWindow.querySelector('.pax-header');
            if (!header) return;

            // Create mode switcher tabs
            const switcher = document.createElement('div');
            switcher.className = 'pax-mode-switcher';
            switcher.innerHTML = `
                <button class="pax-mode-tab ${this.currentMode === 'assistant' ? 'active' : ''}" data-mode="assistant">
                    <span class="dashicons dashicons-format-chat"></span>
                    <span class="pax-mode-label">Assistant</span>
                </button>
                <button class="pax-mode-tab ${this.currentMode === 'liveagent' ? 'active' : ''}" data-mode="liveagent">
                    <span class="dashicons dashicons-businessman"></span>
                    <span class="pax-mode-label">Live Agent</span>
                    <span class="pax-unread-badge" style="display: none;">0</span>
                </button>
            `;

            // Insert after header title
            const titleDiv = header.querySelector('div');
            if (titleDiv) {
                titleDiv.after(switcher);
            } else {
                header.appendChild(switcher);
            }

            this.modeSwitcher = switcher;

            // Add click handlers
            switcher.querySelectorAll('.pax-mode-tab').forEach(tab => {
                tab.addEventListener('click', (e) => {
                    e.preventDefault();
                    const mode = tab.dataset.mode;
                    if (mode !== this.currentMode) {
                        this.switchMode(mode);
                    }
                });
            });
        }

        setupEventListeners() {
            // Send button
            if (this.sendButton) {
                this.sendButton.addEventListener('click', () => this.handleSend());
            }

            // Input field - Enter key
            if (this.inputField) {
                this.inputField.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.handleSend();
                    }
                });
            }

            // Reply-to close buttons (delegated)
            this.messageContainer.addEventListener('click', (e) => {
                if (e.target.closest('.pax-reply-close')) {
                    this.clearReplyTo();
                }
                
                // Reply-to message click
                if (e.target.closest('.pax-reply-to-msg')) {
                    const msgId = e.target.closest('.pax-reply-to-msg').dataset.replyTo;
                    this.scrollToMessage(msgId);
                }

                // Set reply-to
                if (e.target.closest('.pax-msg-reply-btn')) {
                    const msgElement = e.target.closest('.pax-message');
                    if (msgElement) {
                        const msgId = msgElement.dataset.messageId;
                        const msgText = msgElement.querySelector('.pax-msg-text')?.textContent || '';
                        const msgSender = msgElement.classList.contains('pax-msg-user') ? 'user' : 'assistant';
                        this.setReplyTo(msgId, msgText, msgSender);
                    }
                }
            });

            // Window unload - save state
            window.addEventListener('beforeunload', () => this.saveState());
        }

        setupChatMenu() {
            const menuBtn = document.getElementById('pax-menu-btn');
            if (!menuBtn) {
                console.warn('PAX: Menu button not found');
                return;
            }

            console.log('PAX: Setting up chat menu');

            // Create menu dropdown
            const menuDropdown = document.createElement('div');
            menuDropdown.className = 'pax-menu-dropdown';
            menuDropdown.id = 'pax-menu-dropdown';
            menuDropdown.style.display = 'none';

            // Get menu items from settings
            const menuItems = window.paxSupportPro?.menuItems || {};
            const menuIcons = window.paxSupportPro?.menuIcons || {};

            console.log('PAX: Menu items from settings:', menuItems);

            let menuHTML = '';
            let itemCount = 0;
            for (const [key, item] of Object.entries(menuItems)) {
                // Always show items for testing - ignore visibility setting
                const icon = menuIcons[key] || 'dashicons-admin-generic';
                const label = item.label || key;

                menuHTML += `
                    <button class="pax-menu-item" data-action="${key}">
                        <span class="dashicons ${icon}"></span>
                        <span>${label}</span>
                    </button>
                `;
                itemCount++;
            }

            console.log(`PAX: Created ${itemCount} menu items`);

            menuDropdown.innerHTML = menuHTML;
            this.chatWindow.appendChild(menuDropdown);

            // Toggle menu
            menuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('PAX: Menu button clicked');
                this.closeQuickActionsMenu(); // Close other menu
                const isVisible = menuDropdown.style.display !== 'none';
                menuDropdown.style.display = isVisible ? 'none' : 'block';
                console.log('PAX: Menu display:', menuDropdown.style.display);
            });

            // Close menu on outside click
            document.addEventListener('click', (e) => {
                if (!menuDropdown.contains(e.target) && e.target !== menuBtn) {
                    menuDropdown.style.display = 'none';
                }
            });

            // Handle menu item clicks
            menuDropdown.addEventListener('click', (e) => {
                console.log('PAX: Menu dropdown clicked', e.target);
                const item = e.target.closest('.pax-menu-item');
                if (!item) {
                    console.log('PAX: Not a menu item');
                    return;
                }

                const action = item.dataset.action;
                console.log('PAX: Menu action triggered:', action);
                menuDropdown.style.display = 'none';

                this.handleMenuAction(action);
            });

            console.log('PAX: Chat menu setup complete');
        }

        setupQuickActions() {
            const actionsBtn = document.getElementById('pax-head-more');
            if (!actionsBtn) return;

            // Create quick actions dropdown
            const actionsDropdown = document.createElement('div');
            actionsDropdown.className = 'pax-quick-actions-dropdown';
            actionsDropdown.id = 'pax-quick-actions-dropdown';
            actionsDropdown.style.display = 'none';

            actionsDropdown.innerHTML = `
                <button class="pax-qa-item" data-action="reload">
                    <span class="dashicons dashicons-update"></span>
                    <span>Reload Chat</span>
                </button>
                <button class="pax-qa-item" data-action="clear">
                    <span class="dashicons dashicons-trash"></span>
                    <span>Clear Chat</span>
                </button>
                ${window.paxSupportPro?.aiEnabled ? `
                <button class="pax-qa-item" data-action="toggle-ai">
                    <span class="dashicons dashicons-admin-generic"></span>
                    <span>Toggle AI</span>
                </button>
                ` : ''}
                <button class="pax-qa-item" data-action="settings">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <span>Settings</span>
                </button>
            `;

            this.chatWindow.appendChild(actionsDropdown);

            // Toggle menu
            actionsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.closeChatMenu(); // Close other menu
                const isVisible = actionsDropdown.style.display !== 'none';
                actionsDropdown.style.display = isVisible ? 'none' : 'block';
            });

            // Close menu on outside click
            document.addEventListener('click', (e) => {
                if (!actionsDropdown.contains(e.target) && e.target !== actionsBtn) {
                    actionsDropdown.style.display = 'none';
                }
            });

            // Handle actions
            actionsDropdown.addEventListener('click', (e) => {
                const item = e.target.closest('.pax-qa-item');
                if (!item) return;

                const action = item.dataset.action;
                actionsDropdown.style.display = 'none';

                switch (action) {
                    case 'reload':
                        this.reloadConversation();
                        break;
                    case 'clear':
                        this.clearChat();
                        break;
                    case 'toggle-ai':
                        this.toggleAI();
                        break;
                    case 'settings':
                        this.showSettings();
                        break;
                }
            });
        }

        closeChatMenu() {
            const menu = document.getElementById('pax-menu-dropdown');
            if (menu) menu.style.display = 'none';
        }

        closeQuickActionsMenu() {
            const menu = document.getElementById('pax-quick-actions-dropdown');
            if (menu) menu.style.display = 'none';
        }

        handleMenuAction(action) {
            // Handle menu item actions from settings
            console.log('PAX: handleMenuAction called with action:', action);
            
            // Handle specific actions
            switch (action) {
                case 'help':
                    console.log('PAX: Opening Help Center');
                    this.openHelpCenter();
                    break;
                case 'chat':
                    console.log('PAX: Focusing chat input');
                    // Already in chat, just focus input
                    if (this.inputField) {
                        this.inputField.focus();
                    }
                    break;
                case 'ticket':
                    console.log('PAX: Opening New Ticket');
                    this.openNewTicket();
                    break;
                case 'whatsnew':
                    console.log('PAX: Opening What\'s New');
                    this.openWhatsNew();
                    break;
                case 'troubleshooter':
                    console.log('PAX: Opening Troubleshooter');
                    this.openTroubleshooter();
                    break;
                case 'diag':
                    console.log('PAX: Opening Diagnostics');
                    this.openDiagnostics();
                    break;
                case 'callback':
                    console.log('PAX: Opening Callback');
                    this.openCallback();
                    break;
                case 'order':
                    console.log('PAX: Opening Order Lookup');
                    this.openOrderLookup();
                    break;
                case 'myreq':
                    console.log('PAX: Opening My Request');
                    this.openMyRequest();
                    break;
                case 'feedback':
                    console.log('PAX: Opening Feedback');
                    this.openFeedback();
                    break;
                case 'donate':
                    console.log('PAX: Opening Donate');
                    this.openDonate();
                    break;
                case 'speed':
                    console.log('PAX: Toggling Speed');
                    this.toggleSpeed();
                    break;
                default:
                    console.log('PAX: Unknown action, dispatching event:', action);
                    // Trigger existing menu handler if available
                    const event = new CustomEvent('pax-menu-action', { detail: { action } });
                    document.dispatchEvent(event);
                    break;
            }
        }

        openNewTicket() {
            // Check if user is logged in
            if (!window.paxSupportPro?.isLoggedIn) {
                this.showToast('Please log in to create a support ticket.');
                return;
            }

            // Trigger existing ticket modal if available
            const event = new CustomEvent('pax-open-ticket-modal');
            document.dispatchEvent(event);
        }

        openWhatsNew() {
            const url = window.paxSupportPro?.links?.whatsNew;
            if (url) {
                window.open(url, '_blank', 'noopener,noreferrer');
            } else {
                this.showToast('Coming soon!');
            }
        }

        openTroubleshooter() {
            // Trigger existing troubleshooter modal
            const event = new CustomEvent('pax-open-troubleshooter');
            document.dispatchEvent(event);
        }

        openDiagnostics() {
            // Trigger existing diagnostics modal
            const event = new CustomEvent('pax-open-diagnostics');
            document.dispatchEvent(event);
        }

        openCallback() {
            // Check if user is logged in
            if (!window.paxSupportPro?.isLoggedIn) {
                this.showToast('Please log in to request a callback.');
                return;
            }

            // Trigger existing callback/schedule modal
            const event = new CustomEvent('pax-open-schedule-modal');
            document.dispatchEvent(event);
        }

        openOrderLookup() {
            // Trigger existing order lookup modal
            const event = new CustomEvent('pax-open-order-modal');
            document.dispatchEvent(event);
        }

        openMyRequest() {
            // Check if user is logged in
            if (!window.paxSupportPro?.isLoggedIn) {
                this.showToast('Please log in to view your requests.');
                return;
            }

            // Trigger existing my request modal
            const event = new CustomEvent('pax-open-myrequest');
            document.dispatchEvent(event);
        }

        openFeedback() {
            // Trigger existing feedback modal
            const event = new CustomEvent('pax-open-feedback');
            document.dispatchEvent(event);
        }

        openDonate() {
            const url = window.paxSupportPro?.links?.donate;
            if (url) {
                window.open(url, '_blank', 'noopener,noreferrer');
            } else {
                this.showToast('Thank you for your support!');
            }
        }

        toggleSpeed() {
            // Trigger existing speed toggle
            const event = new CustomEvent('pax-toggle-speed');
            document.dispatchEvent(event);
        }

        showToast(message) {
            console.log('PAX: showToast called with message:', message);
            
            // Create toast notification
            let stack = document.getElementById('pax-toast-stack');
            if (!stack) {
                stack = document.createElement('div');
                stack.id = 'pax-toast-stack';
                stack.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999999;display:flex;flex-direction:column;gap:10px;';
                document.body.appendChild(stack);
            }

            const toast = document.createElement('div');
            toast.className = 'pax-toast';
            toast.textContent = message;
            toast.style.cssText = 'background:rgba(20,20,30,0.95);color:#fff;padding:12px 20px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.3);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.1);font-size:14px;opacity:0;transform:translateY(10px);transition:all 0.3s ease;';
            
            stack.appendChild(toast);
            
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });

            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(10px)';
                setTimeout(() => {
                    toast.remove();
                    if (stack.children.length === 0) {
                        stack.remove();
                    }
                }, 300);
            }, 3000);
        }

        showSettings() {
            // Placeholder for settings modal
            alert('Settings feature coming soon!');
        }

        openHelpCenter() {
            console.log('PAX: openHelpCenter called');
            
            // Close any open menus
            this.closeChatMenu();
            this.closeQuickActionsMenu();

            // Check if popup already exists
            let popup = document.getElementById('pax-help-center-popup');
            if (popup) {
                console.log('PAX: Help Center popup already exists, opening it');
                popup.classList.add('open');
                this.lockBodyScroll();
                return;
            }

            console.log('PAX: Creating new Help Center popup');

            // Create popup structure
            popup = document.createElement('div');
            popup.id = 'pax-help-center-popup';
            popup.className = 'pax-help-center-popup';
            popup.innerHTML = `
                <div class="pax-help-overlay"></div>
                <div class="pax-help-modal">
                    <div class="pax-help-header">
                        <h2 class="pax-help-title">
                            <span class="dashicons dashicons-editor-help"></span>
                            Help Center
                        </h2>
                        <button class="pax-help-close" type="button" title="Close">
                            <svg viewBox="0 0 24 24"><path d="M6.7 5.3 5.3 6.7 10.6 12l-5.3 5.3 1.4 1.4L12 13.4l5.3 5.3 1.4-1.4L13.4 12l5.3-5.3-1.4-1.4L12 10.6z"/></svg>
                        </button>
                    </div>
                    <div class="pax-help-search">
                        <span class="dashicons dashicons-search"></span>
                        <input type="text" id="pax-help-search-input" placeholder="Search help articles..." />
                    </div>
                    <div class="pax-help-content">
                        <div class="pax-help-loading">
                            <div class="pax-spinner"></div>
                            <p>Loading help articles...</p>
                        </div>
                    </div>
                </div>
            `;

            document.body.appendChild(popup);

            // Setup event listeners
            this.setupHelpCenterListeners(popup);

            // Load help articles
            this.loadHelpArticles();

            // Show popup with animation
            setTimeout(() => {
                popup.classList.add('open');
                this.lockBodyScroll();
            }, 10);
        }

        setupHelpCenterListeners(popup) {
            // Close button
            const closeBtn = popup.querySelector('.pax-help-close');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => this.closeHelpCenter());
            }

            // Overlay click
            const overlay = popup.querySelector('.pax-help-overlay');
            if (overlay) {
                overlay.addEventListener('click', () => this.closeHelpCenter());
            }

            // ESC key
            const escHandler = (e) => {
                if (e.key === 'Escape' && popup.classList.contains('open')) {
                    this.closeHelpCenter();
                }
            };
            document.addEventListener('keydown', escHandler);
            popup.dataset.escHandler = 'attached';

            // Search input
            const searchInput = popup.querySelector('#pax-help-search-input');
            if (searchInput) {
                let searchTimeout;
                searchInput.addEventListener('input', (e) => {
                    clearTimeout(searchTimeout);
                    searchTimeout = setTimeout(() => {
                        this.loadHelpArticles(e.target.value);
                    }, 500);
                });
            }
        }

        async loadHelpArticles(query = '') {
            const popup = document.getElementById('pax-help-center-popup');
            if (!popup) return;

            const contentDiv = popup.querySelector('.pax-help-content');
            if (!contentDiv) return;

            // Show loading
            contentDiv.innerHTML = `
                <div class="pax-help-loading">
                    <div class="pax-spinner"></div>
                    <p>Loading help articles...</p>
                </div>
            `;

            try {
                const url = new URL(window.paxSupportPro.rest.help);
                if (query) {
                    url.searchParams.append('q', query);
                }
                url.searchParams.append('lang', window.paxSupportPro.locale);

                const response = await fetch(url, {
                    method: 'GET',
                    headers: {
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    }
                });

                const data = await response.json();

                if (data.articles && data.articles.length > 0) {
                    this.renderHelpArticles(data.articles);
                } else {
                    contentDiv.innerHTML = `
                        <div class="pax-help-empty">
                            <span class="dashicons dashicons-info"></span>
                            <p>No help articles found. Try a different search term.</p>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Error loading help articles:', error);
                contentDiv.innerHTML = `
                    <div class="pax-help-error">
                        <span class="dashicons dashicons-warning"></span>
                        <p>Failed to load help articles. Please try again.</p>
                    </div>
                `;
            }
        }

        renderHelpArticles(articles) {
            const popup = document.getElementById('pax-help-center-popup');
            if (!popup) return;

            const contentDiv = popup.querySelector('.pax-help-content');
            if (!contentDiv) return;

            // Get last open section from localStorage
            const lastOpen = localStorage.getItem('pax-help-last-open');

            let html = '<div class="pax-help-articles">';
            
            articles.forEach((article, index) => {
                const isOpen = lastOpen === `article-${index}`;
                html += `
                    <div class="pax-help-article ${isOpen ? 'open' : ''}" data-article-id="article-${index}">
                        <div class="pax-help-article-header">
                            <h3 class="pax-help-article-title">${this.escapeHtml(article.title)}</h3>
                            <button class="pax-help-article-toggle" type="button">
                                <svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
                            </button>
                        </div>
                        <div class="pax-help-article-content">
                            <p class="pax-help-article-summary">${this.escapeHtml(article.summary)}</p>
                            ${article.url ? `<a href="${this.escapeHtml(article.url)}" class="pax-help-article-link" target="_blank" rel="noopener">Read full article →</a>` : ''}
                        </div>
                    </div>
                `;
            });

            html += '</div>';
            contentDiv.innerHTML = html;

            // Setup accordion functionality
            this.setupHelpAccordion();
        }

        setupHelpAccordion() {
            const articles = document.querySelectorAll('.pax-help-article');
            
            articles.forEach(article => {
                const header = article.querySelector('.pax-help-article-header');
                const toggle = article.querySelector('.pax-help-article-toggle');
                
                const clickHandler = () => {
                    const isOpen = article.classList.contains('open');
                    
                    // Close all other articles
                    articles.forEach(a => a.classList.remove('open'));
                    
                    // Toggle current article
                    if (!isOpen) {
                        article.classList.add('open');
                        // Remember last open section
                        localStorage.setItem('pax-help-last-open', article.dataset.articleId);
                    } else {
                        localStorage.removeItem('pax-help-last-open');
                    }
                };

                header.addEventListener('click', clickHandler);
                toggle.addEventListener('click', (e) => {
                    e.stopPropagation();
                    clickHandler();
                });
            });
        }

        closeHelpCenter() {
            const popup = document.getElementById('pax-help-center-popup');
            if (!popup) return;

            popup.classList.remove('open');
            this.unlockBodyScroll();

            // Remove popup after animation
            setTimeout(() => {
                if (popup.parentNode) {
                    popup.parentNode.removeChild(popup);
                }
            }, 300);
        }

        lockBodyScroll() {
            if (window.innerWidth <= 768) {
                document.body.style.overflow = 'hidden';
                document.body.style.position = 'fixed';
                document.body.style.width = '100%';
            }
        }

        unlockBodyScroll() {
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.width = '';
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        async switchMode(mode, saveState = true) {
            if (mode !== 'assistant' && mode !== 'liveagent') {
                console.error('Invalid mode:', mode);
                return;
            }

            // Save current state
            if (saveState) {
                this.saveState();
            }

            // Stop polling if switching away from liveagent
            if (this.currentMode === 'liveagent' && mode !== 'liveagent') {
                this.stopPolling();
            }

            // Update mode
            this.currentMode = mode;

            // Update UI
            this.updateModeUI();

            // Load messages for new mode
            this.renderMessages();

            // Update input placeholder
            if (this.inputField) {
                this.inputField.placeholder = mode === 'liveagent' 
                    ? 'Type your message to agent...'
                    : 'Ask me anything...';
            }

            // Start polling for liveagent
            if (mode === 'liveagent') {
                await this.ensureLiveAgentSession();
                this.startPolling();
            }

            // Clear unread badge for switched mode
            if (mode === 'liveagent') {
                this.sessions.liveagent.unreadCount = 0;
                this.updateUnreadBadge();
            }

            // Save state
            if (saveState) {
                this.saveState();
            }

            console.log('Switched to', mode, 'mode');
        }

        updateModeUI() {
            // Update tab active state
            if (this.modeSwitcher) {
                this.modeSwitcher.querySelectorAll('.pax-mode-tab').forEach(tab => {
                    tab.classList.toggle('active', tab.dataset.mode === this.currentMode);
                });
            }

            // Update header subtitle
            const subtitle = this.chatWindow.querySelector('.pax-sub');
            if (subtitle) {
                subtitle.textContent = this.currentMode === 'liveagent' ? 'Live Agent' : 'Assistant';
            }

            // Update chat window class
            this.chatWindow.classList.toggle('mode-liveagent', this.currentMode === 'liveagent');
            this.chatWindow.classList.toggle('mode-assistant', this.currentMode === 'assistant');
        }

        async handleSend() {
            if (!this.inputField || !this.inputField.value.trim()) {
                return;
            }

            const message = this.inputField.value.trim();
            const replyTo = this.replyToMessage;

            // Clear input and reply-to
            this.inputField.value = '';
            this.clearReplyTo();

            // Add user message to UI immediately
            const userMsg = {
                id: Date.now(),
                text: message,
                sender: 'user',
                timestamp: new Date().toISOString(),
                replyTo: replyTo ? replyTo.id : null
            };

            this.sessions[this.currentMode].messages.push(userMsg);
            this.renderMessage(userMsg);
            this.scrollToBottom();

            // Send to server
            try {
                if (this.currentMode === 'assistant') {
                    await this.sendAssistantMessage(message, replyTo);
                } else {
                    await this.sendLiveAgentMessage(message, replyTo);
                }
            } catch (error) {
                console.error('Error sending message:', error);
                this.showError('Failed to send message. Please try again.');
            }
        }

        async sendAssistantMessage(message, replyTo) {
            // Show typing indicator
            this.showTypingIndicator();

            try {
                const response = await fetch(window.paxSupportPro.rest.ai, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    },
                    body: JSON.stringify({
                        message: message,
                        replyTo: replyTo ? replyTo.id : null,
                        lang: window.paxSupportPro.locale
                    })
                });

                const data = await response.json();

                // Hide typing indicator
                this.hideTypingIndicator();

                if (data.reply) {
                    const assistantMsg = {
                        id: Date.now() + 1,
                        text: data.reply,
                        sender: 'assistant',
                        timestamp: new Date().toISOString(),
                        replyTo: null
                    };

                    this.sessions.assistant.messages.push(assistantMsg);
                    this.renderMessage(assistantMsg);
                    this.scrollToBottom();
                    this.saveState();
                }
            } catch (error) {
                // Hide typing indicator on error
                this.hideTypingIndicator();
                throw error;
            }
        }

        showTypingIndicator() {
            // Remove existing indicator if any
            this.hideTypingIndicator();

            const indicator = document.createElement('div');
            indicator.className = 'pax-typing-indicator';
            indicator.id = 'pax-typing-indicator';
            indicator.innerHTML = `
                <div class="pax-typing-dots">
                    <span class="pax-typing-dot"></span>
                    <span class="pax-typing-dot"></span>
                    <span class="pax-typing-dot"></span>
                </div>
            `;

            this.messageContainer.appendChild(indicator);
            this.scrollToBottom();
        }

        hideTypingIndicator() {
            const indicator = document.getElementById('pax-typing-indicator');
            if (indicator) {
                indicator.remove();
            }
        }

        async sendLiveAgentMessage(message, replyTo) {
            const sessionId = this.sessions.liveagent.sessionId;
            
            if (!sessionId) {
                throw new Error('No active Live Agent session');
            }

            const response = await fetch(window.paxSupportPro.rest.liveagent.send, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': window.paxSupportPro.nonce
                },
                body: JSON.stringify({
                    session_id: sessionId,
                    message: message,
                    reply_to: replyTo ? replyTo.id : null
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to send message');
            }

            // Message will be reflected in next poll
            this.saveState();
        }

        async ensureLiveAgentSession() {
            if (this.sessions.liveagent.sessionId) {
                return;
            }

            try {
                const response = await fetch(window.paxSupportPro.rest.liveagent.create, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    },
                    body: JSON.stringify({})
                });

                const data = await response.json();

                if (data.session_id) {
                    this.sessions.liveagent.sessionId = data.session_id;
                    this.sessions.liveagent.status = data.status || 'pending';
                    this.saveState();
                    console.log('Live Agent session created:', data.session_id);
                }
            } catch (error) {
                console.error('Error creating Live Agent session:', error);
            }
        }

        startPolling() {
            if (this.isPolling) return;

            this.isPolling = true;
            this.pollInterval = setInterval(() => this.pollLiveAgentMessages(), 3000);
            
            // Initial poll
            this.pollLiveAgentMessages();
        }

        stopPolling() {
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
                this.pollInterval = null;
            }
            this.isPolling = false;
        }

        async pollLiveAgentMessages() {
            if (!this.sessions.liveagent.sessionId) return;

            try {
                const response = await fetch(window.paxSupportPro.rest.liveagent.poll + '?session_id=' + this.sessions.liveagent.sessionId, {
                    headers: {
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    }
                });

                const data = await response.json();

                if (data.messages && Array.isArray(data.messages)) {
                    let hasNewMessages = false;

                    data.messages.forEach(msg => {
                        // Check if message already exists
                        const exists = this.sessions.liveagent.messages.some(m => m.id === msg.id);
                        
                        if (!exists) {
                            this.sessions.liveagent.messages.push(msg);
                            
                            // Only render if in liveagent mode
                            if (this.currentMode === 'liveagent') {
                                this.renderMessage(msg);
                                hasNewMessages = true;
                            } else {
                                // Increment unread count
                                this.sessions.liveagent.unreadCount++;
                                this.updateUnreadBadge();
                            }
                        }
                    });

                    if (hasNewMessages) {
                        this.scrollToBottom();
                        this.saveState();
                    }
                }

                // Update status
                if (data.status) {
                    this.sessions.liveagent.status = data.status;
                }

                // Update agent info
                if (data.agent) {
                    this.sessions.liveagent.agentInfo = data.agent;
                }
            } catch (error) {
                console.error('Error polling Live Agent messages:', error);
            }
        }

        updateUnreadBadge() {
            if (!this.modeSwitcher) return;

            const badge = this.modeSwitcher.querySelector('.pax-unread-badge');
            if (!badge) return;

            const count = this.sessions.liveagent.unreadCount;
            
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }

        renderMessages() {
            if (!this.messageContainer) return;

            // Clear container
            this.messageContainer.innerHTML = '';

            // Render all messages for current mode
            const messages = this.sessions[this.currentMode].messages;
            messages.forEach(msg => this.renderMessage(msg));

            this.scrollToBottom();
        }

        renderMessage(msg) {
            if (!this.messageContainer) return;

            const msgDiv = document.createElement('div');
            msgDiv.className = `pax-message pax-msg-${msg.sender}`;
            msgDiv.dataset.messageId = msg.id;

            let content = '';

            // Reply-to context bubble
            if (msg.replyTo) {
                const replyToMsg = this.sessions[this.currentMode].messages.find(m => m.id == msg.replyTo);
                if (replyToMsg) {
                    content += `
                        <div class="pax-reply-to-msg" data-reply-to="${replyToMsg.id}">
                            <span class="dashicons dashicons-undo"></span>
                            <div class="pax-reply-content">
                                <div class="pax-reply-sender">${replyToMsg.sender === 'user' ? 'You' : (replyToMsg.sender === 'agent' ? 'Agent' : 'Assistant')}</div>
                                <div class="pax-reply-text">${this.escapeHtml(replyToMsg.text.substring(0, 50))}${replyToMsg.text.length > 50 ? '...' : ''}</div>
                            </div>
                        </div>
                    `;
                }
            }

            // Message text
            content += `<div class="pax-msg-text">${this.escapeHtml(msg.text)}</div>`;

            // Timestamp
            const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            content += `<div class="pax-msg-time">${time}</div>`;

            // Reply button (if reply-to enabled)
            if (window.paxSupportPro?.options?.enable_reply_to && msg.sender !== 'user') {
                content += `<button class="pax-msg-reply-btn" title="Reply to this message"><span class="dashicons dashicons-undo"></span></button>`;
            }

            msgDiv.innerHTML = content;
            this.messageContainer.appendChild(msgDiv);
        }

        setReplyTo(msgId, msgText, msgSender) {
            this.replyToMessage = { id: msgId, text: msgText, sender: msgSender };

            // Show reply-to indicator
            let indicator = this.chatWindow.querySelector('.pax-reply-indicator');
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'pax-reply-indicator';
                const inputArea = this.chatWindow.querySelector('.pax-input-area');
                if (inputArea) {
                    inputArea.before(indicator);
                }
            }

            indicator.innerHTML = `
                <div class="pax-reply-content">
                    <span class="dashicons dashicons-undo"></span>
                    <div>
                        <div class="pax-reply-to-label">Replying to ${msgSender === 'user' ? 'yourself' : msgSender}</div>
                        <div class="pax-reply-to-text">${this.escapeHtml(msgText.substring(0, 50))}${msgText.length > 50 ? '...' : ''}</div>
                    </div>
                </div>
                <button class="pax-reply-close"><span class="dashicons dashicons-no-alt"></span></button>
            `;
            indicator.style.display = 'flex';

            // Focus input
            if (this.inputField) {
                this.inputField.focus();
            }
        }

        clearReplyTo() {
            this.replyToMessage = null;
            const indicator = this.chatWindow.querySelector('.pax-reply-indicator');
            if (indicator) {
                indicator.style.display = 'none';
            }
        }

        scrollToMessage(msgId) {
            const msgElement = this.messageContainer.querySelector(`[data-message-id="${msgId}"]`);
            if (msgElement) {
                msgElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                msgElement.classList.add('pax-msg-highlight');
                setTimeout(() => msgElement.classList.remove('pax-msg-highlight'), 2000);
            }
        }

        scrollToBottom() {
            if (this.messageContainer) {
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }

        showWelcomeMessage() {
            if (!window.paxSupportPro?.options?.welcome_message) return;

            const welcomeMsg = {
                id: 'welcome-' + Date.now(),
                text: window.paxSupportPro.options.welcome_message,
                sender: 'assistant',
                timestamp: new Date().toISOString(),
                replyTo: null
            };

            this.sessions.assistant.messages.push(welcomeMsg);
            this.renderMessage(welcomeMsg);
        }

        showError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'pax-error-message';
            errorDiv.textContent = message;
            this.messageContainer.appendChild(errorDiv);
            this.scrollToBottom();

            setTimeout(() => errorDiv.remove(), 5000);
        }

        // Quick Actions
        reloadConversation() {
            if (confirm('Reload conversation? This will refresh messages from the server.')) {
                this.sessions[this.currentMode].messages = [];
                this.renderMessages();
                
                if (this.currentMode === 'liveagent') {
                    this.pollLiveAgentMessages();
                }
            }
        }

        clearChat() {
            if (confirm('Clear all messages? This cannot be undone.')) {
                this.sessions[this.currentMode].messages = [];
                this.renderMessages();
                this.saveState();
                this.showWelcomeMessage();
            }
        }

        toggleAI() {
            // This would toggle AI assistant on/off
            console.log('Toggle AI - Not implemented yet');
        }

        // State Management
        saveState() {
            try {
                const state = {
                    currentMode: this.currentMode,
                    sessions: this.sessions,
                    timestamp: Date.now()
                };
                localStorage.setItem('pax_unified_chat_state', JSON.stringify(state));
            } catch (error) {
                console.error('Error saving state:', error);
            }
        }

        loadState() {
            try {
                const saved = localStorage.getItem('pax_unified_chat_state');
                if (!saved) return;

                const state = JSON.parse(saved);
                
                // Check if state is recent (within 24 hours)
                if (Date.now() - state.timestamp > 24 * 60 * 60 * 1000) {
                    localStorage.removeItem('pax_unified_chat_state');
                    return;
                }

                this.currentMode = state.currentMode || 'assistant';
                this.sessions = state.sessions || this.sessions;

                console.log('State loaded from localStorage');
            } catch (error) {
                console.error('Error loading state:', error);
            }
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    // Initialize when ready
    if (typeof window !== 'undefined') {
        window.PAXUnifiedChat = PAXUnifiedChat;
        
        // Auto-initialize and expose instance
        const paxChatInstance = new PAXUnifiedChat();
        window.paxUnifiedChat = paxChatInstance;
        
        console.log('PAX: Unified Chat initialized and exposed as window.paxUnifiedChat');
        console.log('PAX: You can test menu actions directly, e.g., window.paxUnifiedChat.openHelpCenter()');
    }
})();
