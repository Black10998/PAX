/**
 * PAX Support Pro - Unified Chat Engine
 * Merges Assistant + Live Agent into single interface with mode switching
 * 
 * @package PAX_Support_Pro
 * @version 5.4.2
 */

(function() {
    'use strict';

    class PAXUnifiedChat {
        constructor() {
            this.currentMode = 'assistant'; // 'assistant' | 'liveagent'
            this.sessions = {
                assistant: {
                    messages: [],
                    context: {},
                    history: []
                },
                liveagent: {
                    sessionId: null,
                    messages: [],
                    status: 'idle', // 'idle' | 'pending' | 'active' | 'closed'
                    agentInfo: null,
                    unreadCount: 0
                }
            };
            this.replyToMessage = null;
            this.pollInterval = null;
            this.isPolling = false;
            this.lastMessageId = 0;
            
            // DOM elements
            this.chatWindow = null;
            this.messageContainer = null;
            this.inputField = null;
            this.sendButton = null;
            this.modeSwitcher = null;
            
            this.init();
        }

        init() {
            // Wait for DOM ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.setup());
            } else {
                this.setup();
            }
        }

        setup() {
            // Get DOM elements
            this.chatWindow = document.getElementById('pax-chat');
            this.messageContainer = document.getElementById('pax-messages');
            this.inputField = document.getElementById('pax-input');
            this.sendButton = document.getElementById('pax-send');
            
            if (!this.chatWindow || !this.messageContainer) {
                console.warn('PAX Unified Chat: Required DOM elements not found');
                return;
            }

            // Load saved state
            this.loadState();

            // Setup mode switcher
            this.setupModeSwitcher();

            // Setup event listeners
            this.setupEventListeners();

            // Setup Quick Actions
            this.setupQuickActions();

            // Show welcome message if no messages
            if (this.sessions[this.currentMode].messages.length === 0) {
                this.showWelcomeMessage();
            }

            // Restore current mode
            this.switchMode(this.currentMode, false);

            console.log('PAX Unified Chat initialized in', this.currentMode, 'mode');
        }

        setupModeSwitcher() {
            const header = this.chatWindow.querySelector('.pax-header');
            if (!header) return;

            // Create mode switcher tabs
            const switcher = document.createElement('div');
            switcher.className = 'pax-mode-switcher';
            switcher.innerHTML = `
                <button class="pax-mode-tab ${this.currentMode === 'assistant' ? 'active' : ''}" data-mode="assistant">
                    <span class="dashicons dashicons-format-chat"></span>
                    <span class="pax-mode-label">Assistant</span>
                </button>
                <button class="pax-mode-tab ${this.currentMode === 'liveagent' ? 'active' : ''}" data-mode="liveagent">
                    <span class="dashicons dashicons-businessman"></span>
                    <span class="pax-mode-label">Live Agent</span>
                    <span class="pax-unread-badge" style="display: none;">0</span>
                </button>
            `;

            // Insert after header title
            const titleDiv = header.querySelector('div');
            if (titleDiv) {
                titleDiv.after(switcher);
            } else {
                header.appendChild(switcher);
            }

            this.modeSwitcher = switcher;

            // Add click handlers
            switcher.querySelectorAll('.pax-mode-tab').forEach(tab => {
                tab.addEventListener('click', (e) => {
                    e.preventDefault();
                    const mode = tab.dataset.mode;
                    if (mode !== this.currentMode) {
                        this.switchMode(mode);
                    }
                });
            });
        }

        setupEventListeners() {
            // Send button
            if (this.sendButton) {
                this.sendButton.addEventListener('click', () => this.handleSend());
            }

            // Input field - Enter key
            if (this.inputField) {
                this.inputField.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.handleSend();
                    }
                });
            }

            // Reply-to close buttons (delegated)
            this.messageContainer.addEventListener('click', (e) => {
                if (e.target.closest('.pax-reply-close')) {
                    this.clearReplyTo();
                }
                
                // Reply-to message click
                if (e.target.closest('.pax-reply-to-msg')) {
                    const msgId = e.target.closest('.pax-reply-to-msg').dataset.replyTo;
                    this.scrollToMessage(msgId);
                }

                // Set reply-to
                if (e.target.closest('.pax-msg-reply-btn')) {
                    const msgElement = e.target.closest('.pax-message');
                    if (msgElement) {
                        const msgId = msgElement.dataset.messageId;
                        const msgText = msgElement.querySelector('.pax-msg-text')?.textContent || '';
                        const msgSender = msgElement.classList.contains('pax-msg-user') ? 'user' : 'assistant';
                        this.setReplyTo(msgId, msgText, msgSender);
                    }
                }
            });

            // Window unload - save state
            window.addEventListener('beforeunload', () => this.saveState());
        }

        setupQuickActions() {
            if (!window.paxSupportPro?.options?.enable_quick_actions) {
                return;
            }

            const header = this.chatWindow.querySelector('.pax-header');
            if (!header) return;

            const actionsBtn = document.createElement('button');
            actionsBtn.className = 'pax-quick-actions-btn';
            actionsBtn.innerHTML = '<span class="dashicons dashicons-menu"></span>';
            actionsBtn.title = 'Quick Actions';

            const actionsMenu = document.createElement('div');
            actionsMenu.className = 'pax-quick-actions-menu';
            actionsMenu.style.display = 'none';
            actionsMenu.innerHTML = `
                <button class="pax-qa-item" data-action="reload">
                    <span class="dashicons dashicons-update"></span>
                    Reload Conversation
                </button>
                <button class="pax-qa-item" data-action="clear">
                    <span class="dashicons dashicons-trash"></span>
                    Clear Chat
                </button>
                ${window.paxSupportPro?.aiEnabled ? `
                <button class="pax-qa-item" data-action="toggle-ai">
                    <span class="dashicons dashicons-admin-generic"></span>
                    Toggle AI
                </button>
                ` : ''}
            `;

            header.appendChild(actionsBtn);
            header.appendChild(actionsMenu);

            // Toggle menu
            actionsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isVisible = actionsMenu.style.display !== 'none';
                actionsMenu.style.display = isVisible ? 'none' : 'block';
            });

            // Close menu on outside click
            document.addEventListener('click', () => {
                actionsMenu.style.display = 'none';
            });

            // Handle actions
            actionsMenu.addEventListener('click', (e) => {
                const item = e.target.closest('.pax-qa-item');
                if (!item) return;

                const action = item.dataset.action;
                actionsMenu.style.display = 'none';

                switch (action) {
                    case 'reload':
                        this.reloadConversation();
                        break;
                    case 'clear':
                        this.clearChat();
                        break;
                    case 'toggle-ai':
                        this.toggleAI();
                        break;
                }
            });
        }

        async switchMode(mode, saveState = true) {
            if (mode !== 'assistant' && mode !== 'liveagent') {
                console.error('Invalid mode:', mode);
                return;
            }

            // Save current state
            if (saveState) {
                this.saveState();
            }

            // Stop polling if switching away from liveagent
            if (this.currentMode === 'liveagent' && mode !== 'liveagent') {
                this.stopPolling();
            }

            // Update mode
            this.currentMode = mode;

            // Update UI
            this.updateModeUI();

            // Load messages for new mode
            this.renderMessages();

            // Update input placeholder
            if (this.inputField) {
                this.inputField.placeholder = mode === 'liveagent' 
                    ? 'Type your message to agent...'
                    : 'Ask me anything...';
            }

            // Start polling for liveagent
            if (mode === 'liveagent') {
                await this.ensureLiveAgentSession();
                this.startPolling();
            }

            // Clear unread badge for switched mode
            if (mode === 'liveagent') {
                this.sessions.liveagent.unreadCount = 0;
                this.updateUnreadBadge();
            }

            // Save state
            if (saveState) {
                this.saveState();
            }

            console.log('Switched to', mode, 'mode');
        }

        updateModeUI() {
            // Update tab active state
            if (this.modeSwitcher) {
                this.modeSwitcher.querySelectorAll('.pax-mode-tab').forEach(tab => {
                    tab.classList.toggle('active', tab.dataset.mode === this.currentMode);
                });
            }

            // Update header subtitle
            const subtitle = this.chatWindow.querySelector('.pax-sub');
            if (subtitle) {
                subtitle.textContent = this.currentMode === 'liveagent' ? 'Live Agent' : 'Assistant';
            }

            // Update chat window class
            this.chatWindow.classList.toggle('mode-liveagent', this.currentMode === 'liveagent');
            this.chatWindow.classList.toggle('mode-assistant', this.currentMode === 'assistant');
        }

        async handleSend() {
            if (!this.inputField || !this.inputField.value.trim()) {
                return;
            }

            const message = this.inputField.value.trim();
            const replyTo = this.replyToMessage;

            // Clear input and reply-to
            this.inputField.value = '';
            this.clearReplyTo();

            // Add user message to UI immediately
            const userMsg = {
                id: Date.now(),
                text: message,
                sender: 'user',
                timestamp: new Date().toISOString(),
                replyTo: replyTo ? replyTo.id : null
            };

            this.sessions[this.currentMode].messages.push(userMsg);
            this.renderMessage(userMsg);
            this.scrollToBottom();

            // Send to server
            try {
                if (this.currentMode === 'assistant') {
                    await this.sendAssistantMessage(message, replyTo);
                } else {
                    await this.sendLiveAgentMessage(message, replyTo);
                }
            } catch (error) {
                console.error('Error sending message:', error);
                this.showError('Failed to send message. Please try again.');
            }
        }

        async sendAssistantMessage(message, replyTo) {
            const response = await fetch(window.paxSupportPro.rest.ai, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': window.paxSupportPro.nonce
                },
                body: JSON.stringify({
                    message: message,
                    replyTo: replyTo ? replyTo.id : null,
                    lang: window.paxSupportPro.locale
                })
            });

            const data = await response.json();

            if (data.reply) {
                const assistantMsg = {
                    id: Date.now() + 1,
                    text: data.reply,
                    sender: 'assistant',
                    timestamp: new Date().toISOString(),
                    replyTo: null
                };

                this.sessions.assistant.messages.push(assistantMsg);
                this.renderMessage(assistantMsg);
                this.scrollToBottom();
                this.saveState();
            }
        }

        async sendLiveAgentMessage(message, replyTo) {
            const sessionId = this.sessions.liveagent.sessionId;
            
            if (!sessionId) {
                throw new Error('No active Live Agent session');
            }

            const response = await fetch(window.paxSupportPro.rest.liveagent.send, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': window.paxSupportPro.nonce
                },
                body: JSON.stringify({
                    session_id: sessionId,
                    message: message,
                    reply_to: replyTo ? replyTo.id : null
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to send message');
            }

            // Message will be reflected in next poll
            this.saveState();
        }

        async ensureLiveAgentSession() {
            if (this.sessions.liveagent.sessionId) {
                return;
            }

            try {
                const response = await fetch(window.paxSupportPro.rest.liveagent.create, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    },
                    body: JSON.stringify({})
                });

                const data = await response.json();

                if (data.session_id) {
                    this.sessions.liveagent.sessionId = data.session_id;
                    this.sessions.liveagent.status = data.status || 'pending';
                    this.saveState();
                    console.log('Live Agent session created:', data.session_id);
                }
            } catch (error) {
                console.error('Error creating Live Agent session:', error);
            }
        }

        startPolling() {
            if (this.isPolling) return;

            this.isPolling = true;
            this.pollInterval = setInterval(() => this.pollLiveAgentMessages(), 3000);
            
            // Initial poll
            this.pollLiveAgentMessages();
        }

        stopPolling() {
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
                this.pollInterval = null;
            }
            this.isPolling = false;
        }

        async pollLiveAgentMessages() {
            if (!this.sessions.liveagent.sessionId) return;

            try {
                const response = await fetch(window.paxSupportPro.rest.liveagent.poll + '?session_id=' + this.sessions.liveagent.sessionId, {
                    headers: {
                        'X-WP-Nonce': window.paxSupportPro.nonce
                    }
                });

                const data = await response.json();

                if (data.messages && Array.isArray(data.messages)) {
                    let hasNewMessages = false;

                    data.messages.forEach(msg => {
                        // Check if message already exists
                        const exists = this.sessions.liveagent.messages.some(m => m.id === msg.id);
                        
                        if (!exists) {
                            this.sessions.liveagent.messages.push(msg);
                            
                            // Only render if in liveagent mode
                            if (this.currentMode === 'liveagent') {
                                this.renderMessage(msg);
                                hasNewMessages = true;
                            } else {
                                // Increment unread count
                                this.sessions.liveagent.unreadCount++;
                                this.updateUnreadBadge();
                            }
                        }
                    });

                    if (hasNewMessages) {
                        this.scrollToBottom();
                        this.saveState();
                    }
                }

                // Update status
                if (data.status) {
                    this.sessions.liveagent.status = data.status;
                }

                // Update agent info
                if (data.agent) {
                    this.sessions.liveagent.agentInfo = data.agent;
                }
            } catch (error) {
                console.error('Error polling Live Agent messages:', error);
            }
        }

        updateUnreadBadge() {
            if (!this.modeSwitcher) return;

            const badge = this.modeSwitcher.querySelector('.pax-unread-badge');
            if (!badge) return;

            const count = this.sessions.liveagent.unreadCount;
            
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }

        renderMessages() {
            if (!this.messageContainer) return;

            // Clear container
            this.messageContainer.innerHTML = '';

            // Render all messages for current mode
            const messages = this.sessions[this.currentMode].messages;
            messages.forEach(msg => this.renderMessage(msg));

            this.scrollToBottom();
        }

        renderMessage(msg) {
            if (!this.messageContainer) return;

            const msgDiv = document.createElement('div');
            msgDiv.className = `pax-message pax-msg-${msg.sender}`;
            msgDiv.dataset.messageId = msg.id;

            let content = '';

            // Reply-to context bubble
            if (msg.replyTo) {
                const replyToMsg = this.sessions[this.currentMode].messages.find(m => m.id == msg.replyTo);
                if (replyToMsg) {
                    content += `
                        <div class="pax-reply-to-msg" data-reply-to="${replyToMsg.id}">
                            <span class="dashicons dashicons-undo"></span>
                            <div class="pax-reply-content">
                                <div class="pax-reply-sender">${replyToMsg.sender === 'user' ? 'You' : (replyToMsg.sender === 'agent' ? 'Agent' : 'Assistant')}</div>
                                <div class="pax-reply-text">${this.escapeHtml(replyToMsg.text.substring(0, 50))}${replyToMsg.text.length > 50 ? '...' : ''}</div>
                            </div>
                        </div>
                    `;
                }
            }

            // Message text
            content += `<div class="pax-msg-text">${this.escapeHtml(msg.text)}</div>`;

            // Timestamp
            const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            content += `<div class="pax-msg-time">${time}</div>`;

            // Reply button (if reply-to enabled)
            if (window.paxSupportPro?.options?.enable_reply_to && msg.sender !== 'user') {
                content += `<button class="pax-msg-reply-btn" title="Reply to this message"><span class="dashicons dashicons-undo"></span></button>`;
            }

            msgDiv.innerHTML = content;
            this.messageContainer.appendChild(msgDiv);
        }

        setReplyTo(msgId, msgText, msgSender) {
            this.replyToMessage = { id: msgId, text: msgText, sender: msgSender };

            // Show reply-to indicator
            let indicator = this.chatWindow.querySelector('.pax-reply-indicator');
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'pax-reply-indicator';
                const inputArea = this.chatWindow.querySelector('.pax-input-area');
                if (inputArea) {
                    inputArea.before(indicator);
                }
            }

            indicator.innerHTML = `
                <div class="pax-reply-content">
                    <span class="dashicons dashicons-undo"></span>
                    <div>
                        <div class="pax-reply-to-label">Replying to ${msgSender === 'user' ? 'yourself' : msgSender}</div>
                        <div class="pax-reply-to-text">${this.escapeHtml(msgText.substring(0, 50))}${msgText.length > 50 ? '...' : ''}</div>
                    </div>
                </div>
                <button class="pax-reply-close"><span class="dashicons dashicons-no-alt"></span></button>
            `;
            indicator.style.display = 'flex';

            // Focus input
            if (this.inputField) {
                this.inputField.focus();
            }
        }

        clearReplyTo() {
            this.replyToMessage = null;
            const indicator = this.chatWindow.querySelector('.pax-reply-indicator');
            if (indicator) {
                indicator.style.display = 'none';
            }
        }

        scrollToMessage(msgId) {
            const msgElement = this.messageContainer.querySelector(`[data-message-id="${msgId}"]`);
            if (msgElement) {
                msgElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                msgElement.classList.add('pax-msg-highlight');
                setTimeout(() => msgElement.classList.remove('pax-msg-highlight'), 2000);
            }
        }

        scrollToBottom() {
            if (this.messageContainer) {
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }

        showWelcomeMessage() {
            if (!window.paxSupportPro?.options?.welcome_message) return;

            const welcomeMsg = {
                id: 'welcome-' + Date.now(),
                text: window.paxSupportPro.options.welcome_message,
                sender: 'assistant',
                timestamp: new Date().toISOString(),
                replyTo: null
            };

            this.sessions.assistant.messages.push(welcomeMsg);
            this.renderMessage(welcomeMsg);
        }

        showError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'pax-error-message';
            errorDiv.textContent = message;
            this.messageContainer.appendChild(errorDiv);
            this.scrollToBottom();

            setTimeout(() => errorDiv.remove(), 5000);
        }

        // Quick Actions
        reloadConversation() {
            if (confirm('Reload conversation? This will refresh messages from the server.')) {
                this.sessions[this.currentMode].messages = [];
                this.renderMessages();
                
                if (this.currentMode === 'liveagent') {
                    this.pollLiveAgentMessages();
                }
            }
        }

        clearChat() {
            if (confirm('Clear all messages? This cannot be undone.')) {
                this.sessions[this.currentMode].messages = [];
                this.renderMessages();
                this.saveState();
                this.showWelcomeMessage();
            }
        }

        toggleAI() {
            // This would toggle AI assistant on/off
            console.log('Toggle AI - Not implemented yet');
        }

        // State Management
        saveState() {
            try {
                const state = {
                    currentMode: this.currentMode,
                    sessions: this.sessions,
                    timestamp: Date.now()
                };
                localStorage.setItem('pax_unified_chat_state', JSON.stringify(state));
            } catch (error) {
                console.error('Error saving state:', error);
            }
        }

        loadState() {
            try {
                const saved = localStorage.getItem('pax_unified_chat_state');
                if (!saved) return;

                const state = JSON.parse(saved);
                
                // Check if state is recent (within 24 hours)
                if (Date.now() - state.timestamp > 24 * 60 * 60 * 1000) {
                    localStorage.removeItem('pax_unified_chat_state');
                    return;
                }

                this.currentMode = state.currentMode || 'assistant';
                this.sessions = state.sessions || this.sessions;

                console.log('State loaded from localStorage');
            } catch (error) {
                console.error('Error loading state:', error);
            }
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    // Initialize when ready
    if (typeof window !== 'undefined') {
        window.PAXUnifiedChat = PAXUnifiedChat;
        
        // Auto-initialize
        new PAXUnifiedChat();
    }
})();
